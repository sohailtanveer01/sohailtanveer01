-- phpMyAdmin SQL Dump
-- version 4.9.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Sep 23, 2020 at 04:46 PM
-- Server version: 10.4.10-MariaDB
-- PHP Version: 7.3.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ctrl_budget`
--

-- --------------------------------------------------------

--
-- Table structure for table `budget_plan`
--

DROP TABLE IF EXISTS `budget_plan`;
CREATE TABLE IF NOT EXISTS `budget_plan` (
  `tittle` varchar(255) NOT NULL,
  `from1` date NOT NULL,
  `to1` date NOT NULL,
  `initialbudget` int(14) NOT NULL,
  `noofpeople` int(255) NOT NULL,
  `person1` varchar(45) NOT NULL,
  `person2` varchar(45) NOT NULL,
  `user_id` int(255) NOT NULL,
  `id` int(255) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`),
  KEY `id` (`user_id`),
  KEY `user_id` (`user_id`),
  KEY `user_id_2` (`user_id`),
  KEY `user_id_3` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=43 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `budget_plan`
--

INSERT INTO `budget_plan` (`tittle`, `from1`, `to1`, `initialbudget`, `noofpeople`, `person1`, `person2`, `user_id`, `id`) VALUES
('goa', '2020-09-12', '2020-09-13', 600, 5, 'hashrun', 'ibrahim', 4, 1),
('goa', '2020-09-12', '2020-09-13', 600, 5, 'hashrun', 'ibrahim', 4, 2),
('goa', '2020-09-20', '2020-09-21', 4000, 3, 'hashrun', 'ibrahim', 3, 3),
('goa', '2020-09-20', '2020-09-21', 4000, 3, 'hashrun', 'ibrahim', 3, 4),
('goa', '2020-09-25', '2020-09-26', 40000, 5, 'anwesh', 'stan', 3, 5),
('thailand', '2020-09-26', '2020-09-30', 50000, 5, 'hashrun', 'sathvik', 3, 6),
('thailand', '2020-09-18', '2020-09-19', 1000, 3, 'vinit', 'sathvik', 3, 7),
('malasia', '2020-10-01', '2020-10-12', 1000000, 5, 'vinit', 'sathvik', 3, 8),
('europe', '2020-09-17', '2020-09-23', 40000, 5, 'vinit', 'sathvik', 3, 9),
('goa', '2020-09-04', '2020-09-12', 40000, 5, 'vinit', 'sathvik', 3, 10),
('goa', '2020-09-13', '2020-09-25', 40000, 2, 'vinit', 'sathvik', 3, 12),
('goa', '2020-09-10', '2020-09-15', 40000, 5, 'hashrun', 'ibrahim', 0, 13),
('hyderabad', '2020-09-18', '2020-09-20', 40000, 3, 'vinit', 'sathvik', 3, 14),
('banglore', '2020-09-18', '2020-09-20', 4000, 3, 'vinit', 'sathvik', 3, 15),
('hyderabad', '2020-09-25', '2020-09-30', 500000, 3, 'vinit', 'sathvik', 3, 16),
('goa', '2020-09-19', '2020-09-27', 500, 3, 'vinit', 'sathvik', 3, 17),
('goa', '2020-09-19', '2020-09-27', 40000, 2, 'hashrun', 'ibrahim', 0, 18),
('goa', '2020-09-18', '2020-09-20', 40000, 3, 'vinit', 'sathvik', 3, 19),
('hyderabad', '2020-09-19', '2020-09-27', 40000, 3, 'vinit', 'sathvik', 3, 20),
('thailand', '2020-09-27', '2020-09-30', 50000, 5, 'vinit', 'sathvik', 3, 21),
('nigeria', '2020-09-20', '2020-09-20', 40000, 3, 'vinit', 'sathvik', 3, 22),
('stan', '2020-09-20', '2020-09-24', 500, 2, 'vinit', 'sathvik', 3, 23),
('thailand', '2020-09-20', '2020-09-25', 4000, 2, 'vinit', 'sathvik', 3, 24),
('goa', '2020-09-20', '2020-09-25', 4000, 2, 'vinit', 'sathvik', 3, 25),
('hyderabad', '2020-09-21', '2020-09-25', 1000, 3, 'vinit', 'sathvik', 0, 26),
('goa', '2020-09-21', '2020-09-25', 4000, 2, 'vinit', 'sathvik', 18, 27),
('goa', '2020-09-20', '2020-09-25', 4000, 3, 'vinit', 'sathvik', 18, 28),
('goa', '2020-09-21', '2020-09-25', 4000, 3, 'vinit', 'sathvik', 18, 29),
('goa', '2020-09-23', '2020-09-23', 40000, 2, 'vinit', 'sathvik', 18, 30),
('goa', '2020-09-22', '2020-09-23', 500, 2, 'vinit', 'sathvik', 18, 31),
('goa', '2020-09-22', '2020-09-27', 4000, 2, 'vinit', 'sathvik', 18, 32),
('goa', '2020-09-23', '2020-09-25', 4000, 2, 'vinit', 'sathvik', 18, 33),
('goa', '2020-09-22', '2020-09-25', 4000, 2, 'vinit', 'sathvik', 18, 34),
('thailand', '2020-09-22', '2020-09-25', 4000, 2, 'vinit', 'sathvik', 18, 35),
('goa', '2020-09-22', '2020-09-25', 4000, 2, 'vinit', 'sathvik', 18, 36),
('goa', '2020-09-22', '2020-09-25', 4000, 2, 'vinit', 'sathvik', 18, 37),
('goa', '2020-09-24', '2020-09-26', 5000, 5, 'vinit', 'sathvik', 18, 38),
('goa', '2020-09-23', '2020-09-25', 500, 2, 'vinit', 'sathvik', 18, 39),
('goa', '2020-09-23', '2020-09-26', 4000, 2, 'vinit', 'sathvik', 18, 40),
('goa', '2020-09-23', '2020-09-26', 4000, 2, 'vinit', 'sathvik', 18, 41),
('goa', '2020-09-23', '2020-09-25', 4000, 2, 'vinit', 'sathvik', 18, 42);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `id` int(255) NOT NULL AUTO_INCREMENT,
  `email_id` varchar(255) NOT NULL,
  `first_name` varchar(255) NOT NULL,
  `phone` varchar(22) NOT NULL,
  `password` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `email_id`, `first_name`, `phone`, `password`) VALUES
(2, 'sadiya665@gmail.com', 'sadiya', '7894561231', 'de477712def49217858da9c0d06623ed'),
(4, 'ibrahimadv1973@gmail.com', 'ibrahim', '9885752866', 'de477712def49217858da9c0d06623ed'),
(5, 'jd123@gmail.com', 'jd', '9885752699', 'cd114957c3da62a473ba219b74fcd97b'),
(6, 'sampath123@gmail.com', 'sampath', '9618233898', 'de477712def49217858da9c0d06623ed'),
(13, 'viratkohli17@gmail.com', 'virat', '9885752866', 'de477712def49217858da9c0d06623ed'),
(14, 'gayle333@gmail.com', 'gayle', '9885752866', 'de477712def49217858da9c0d06623ed'),
(16, 'syedhashrun123@gmail.com', 'syedhashrun', '9885752866', 'de477712def49217858da9c0d06623ed'),
(17, 'hashrunsyed@gmail.com', 'hashrun', '9885752866', 'de477712def49217858da9c0d06623ed'),
(18, 'sohailtanveer769@gmail.com', 'sohail', '9885752866', 'de477712def49217858da9c0d06623ed');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
